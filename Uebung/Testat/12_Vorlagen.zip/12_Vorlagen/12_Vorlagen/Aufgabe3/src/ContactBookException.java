public class ContactBookException extends Exception {
	private static final long serialVersionUID = 1L;

	public ContactBookException(String description) {
		super(description);
	}
}
