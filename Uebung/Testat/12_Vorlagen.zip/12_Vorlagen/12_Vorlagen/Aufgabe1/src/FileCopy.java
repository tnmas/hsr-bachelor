import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileCopy {
	public static void main(String[] args) throws IOException{

        @SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);

        System.out.println("Enter the path source file");
        String inputFilePath = scan.nextLine(); 

        System.out.println("Enter the destination path file");
        String outputFilePath = scan.nextLine(); 

        BufferedInputStream input = null;
        BufferedOutputStream output = null;

        try {
            input = new BufferedInputStream(new FileInputStream(inputFilePath));
            output = new BufferedOutputStream(new FileOutputStream(outputFilePath));

            int byteRead;
            while ((byteRead = input.read()) != -1) { 
                output.write(byteRead);
            }

            System.out.println("Done! File is copied successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        } finally { 
            try {
                if (input != null)
                    input.close();
                if (output != null)
                    output.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
	}
}
