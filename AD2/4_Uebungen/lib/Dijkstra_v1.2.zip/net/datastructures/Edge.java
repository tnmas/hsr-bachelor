package net.datastructures;
/**
 * An interface for an edge of a graph.
 * @author Roberto Tamassia
 */
public interface Edge<E> extends DecorablePosition<E> { }
