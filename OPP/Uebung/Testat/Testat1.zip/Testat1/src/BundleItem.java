
public class BundleItem extends Item {

	private double discount;
	private final Item[] items;

	public BundleItem(String description, double discount, Item[] items) {
		super(description);
		this.discount = discount;
		this.items = items;
	}
	
	// Get Items
	public Item[] getItems() {
		return items;
	}
	
	// Get Discount
	public double getDiscount() {
		return discount;
	}
	
	// Set Discount
	public void setDiscount(double discount) {
		this.discount = discount;
	}

	// Get Total Bundle Item Price
	public double getTotalPrice() {

		double total = 0;
		for (Item item : items) {
			total += item.getPrice();
		}
		return total;
	}

	// Get the Discount of Total Bundle Item
	public double getTotalDiscount() {

		double totalDiscount = 0;
		for (Item item : items) {
			totalDiscount += item.getPrice();
		}
		return totalDiscount * (100 - discount) / 100;
	}

//	@Override
//	public double getDiscountPrice() {
//
//		double total = 0;
//		for (Item item : items) {
//			total += item.getPrice();
//		}
//		return total * (100 - discount) / 100;
//	}
	
	// Print Product Items
	public void printItems() {
		String allItems;
		for (Item item : items) {
			allItems = item.getDescription();
			// System.out.println(allItems + item.getPrice());

			System.out.println(allItems + ", One " + item.getDescription() + " Price: " + item.itemPricePerUnit()
					+ ", Product amount: " + item.itemAmount() + ", Total " + item.getDescription() + "(s) Price: "
					+ item.totalItemPrice());
		}
	}

	@Override
	public double getPrice() {
		return 0;
	}

	@Override
	public double itemAmount() {
		return 0;
	}

	@Override
	public double itemPricePerUnit() {
		return 0;
	}

	@Override
	public double totalItemPrice() {
		return 0;
	}

	@Override
	public void print() {
	}
}
