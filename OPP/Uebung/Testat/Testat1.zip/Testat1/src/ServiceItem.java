
public class ServiceItem extends Item {
	public double price;

	public ServiceItem(String description, double price) {
		super(description);
		this.price = price;
	}

	// Set Service Item Price
	public void setPrice(double price) {
		this.price = price;
	}

	// Inherit the Service Item Description from Base Class "Super Class"
	// (Item.java)
	public ServiceItem(String description) {
		super(description);
	}

	// Get Service Item Price
	@Override
	public double getPrice() {
		return price;
	}

	//
	@Override
	public void print() {
		// System.out.println(this.getDescription());
		//	System.out.println(price);
	}

	// Service Item Amount "always 1"
	@Override
	public double itemAmount() {
		return 1;
	}

	// Return Price of singular Service Item "Price Per Unit"
	@Override
	public double itemPricePerUnit() {
		return this.price;
	}

	// Return Total Price of singular Service Item "actually same result of itemPricePerUnit()"
	@Override
	public double totalItemPrice() {
		return this.price * itemAmount();
	}

}
