
public class OrderTest {

	public static void main(String[] args) {
		ProductItem item1 = new ProductItem("Mouse", 5, 40);
		ServiceItem item2 = new ServiceItem("warranty", 10);
		ProductItem item3 = new ProductItem("Monitor", 2, 300);

		Order order = new Order(new Item[] { item1, item2, item3 });

		order.printItems();
		System.out.println("Total Price: " + order.getTotalPrice() + " CHF");
		
		// You can apply the discount also from here, but for the logic, I created a Separated class for the Discount, The name of the class is BundleItemTest
		
//		BundleItem bundleItem = new BundleItem("", 10, new Item[] { item1, item2, item3 });
		
//		bundleItem.printItems();
//		System.out.println("Total Price: " + bundleItem.getTotalPrice() + " CHF");
//		System.out.println("The price after discount: " + bundleItem.getTotalDiscount() + " CHF");
	}
}