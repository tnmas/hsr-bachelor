
public abstract class Item {

	protected final String description;
	private double discount;

	public Item(String description) {
		this.description = description;
	}

	// Get Item Price
	public abstract double getPrice();
	
	// Get Item Amount
	public abstract double itemAmount();
	
	// Price per Item Unit
	public abstract double itemPricePerUnit();
	
	// Total item Price
	public abstract double totalItemPrice();
	
	// Print Items
	public abstract void print();

	// Get Item Description
	public String getDescription() {
		return description;
	}

	// Get Discount Price
	public double getDiscountPrice() {
		return discount;
	}

}
