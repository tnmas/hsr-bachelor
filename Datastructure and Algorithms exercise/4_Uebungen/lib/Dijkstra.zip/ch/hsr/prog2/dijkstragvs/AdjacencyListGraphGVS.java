package ch.hsr.prog2.dijkstragvs;

import gvs.graph.GVSDefaultVertex;
import gvs.graph.GVSGraph;
import gvs.graph.GVSRelativeVertex;
import gvs.graph.GVSUndirectedEdge;
import gvs.typ.edge.GVSEdgeTyp;
import gvs.typ.vertex.GVSVertexTyp;

import java.util.logging.Logger;

import net.datastructures.AdjacencyListGraph;
import net.datastructures.Edge;
import net.datastructures.InvalidPositionException;
import net.datastructures.Position;
import net.datastructures.Vertex;

@SuppressWarnings({"unchecked", "hiding"}) 

public class AdjacencyListGraphGVS<V,E> extends AdjacencyListGraph<V,E> {
  
  
	protected GVSGraph gvsGraph;
	boolean gvsAllwaysDisplaying;
	GvsSupport gvsSupport;
  static final String WEIGHT = "WEIGHT";
  
  private static final Logger log = Logger.getLogger(AdjacencyListGraphGVS.class.getName());

  class MyGvsVertex<V> extends MyVertex<V> implements GVSRelativeVertex {
    
    private GVSVertexTyp gvsTyp;
    private double xPos;
    private double yPos;
    
    MyGvsVertex(V o, double xPos, double yPos) {
      super(o);
      incEdges = new NodePositionListGVS<Edge<E>>(gvsSupport);
      this.xPos = xPos;
      this.yPos = yPos;
    }
    
    @Override
    public String getGVSVertexLabel() {
      return toString();
    }
    
    @Override
    public GVSVertexTyp getGVSVertexTyp() {
      return gvsTyp;
    }
    
    public GVSVertexTyp setGVSVertexTyp(GVSVertexTyp gvsTyp) {
      GVSVertexTyp old = this.gvsTyp;
      this.gvsTyp = gvsTyp;
      return old;
    }
    
    @Override
    public double getX() {
      return xPos; 
    }
    
    @Override
    public double getY() {
      return yPos;
    }
    
    /** Inserts an edge into the incidence container of this vertex. */
    @Override
    public Position<Edge<E>> insertIncidence(Edge<E> e) {
      log.fine(this+" : Edge:"+e);
      if ( ! (e.element() instanceof Comparable)) {
        incEdges.addLast(e);
        return incEdges.last();
      }
      else {
        int size = incEdges.size() ;
        if (size == 0) {
          incEdges.addFirst(e);
          return incEdges.first();
        }
        else {
          MyEdge<E> me = (MyEdge<E>)e;
          MyVertex<V>[] vertices = (MyVertex<V>[])me.endVertices();
          //System.out.println("[0]: "+vertices[0]);
          //System.out.println(vertices[0] == this);
          //System.out.println("[1]: "+vertices[1]);
          //System.out.println(vertices[1] == this);
          MyVertex<V> newVertex = (vertices[0] == this) ? vertices[1] : vertices[0];
          log.fine("newVertex: "+newVertex);
          for (Position<Edge<E>> currentPos: incEdges.positions()) {
            MyEdge<E> currentEdge = (MyEdge<E>)currentPos.element();
            vertices = (MyVertex<V>[])currentEdge.endVertices();
            MyVertex<V> currentVertex = (vertices[0] == this) ? vertices[1] : vertices[0];
            log.fine("currentVertex: "+currentVertex);
            if (((Comparable)newVertex.element()).compareTo(currentVertex.element()) < 0) {
              incEdges.addBefore(currentPos, e);
              printIncidentEdges();
              return incEdges.prev(currentPos);
            }
          }
          // must be last element:
          incEdges.addLast(e);
          printIncidentEdges();
          return incEdges.last();
        }
      }
    }
    
    @Override
    public Iterable<Edge<E>> incidentEdges() {
      return super.incidentEdges();
    }
   
    
    private void printIncidentEdges() {
      StringBuilder buf = new StringBuilder();
      buf.append(this+": ");
      for (Position<Edge<E>> currentPos: incEdges.positions()) {
        buf.append(currentPos.element()+", ");
      }
      log.fine(buf.toString());
    }
    
  } // End of MyGvsVertex
  
  class MyGvsEdge<E> extends MyEdge<E> implements GVSUndirectedEdge {
    
    private String label;
    private GVSEdgeTyp typ;
    private int hasArrow = 0;  // Default: none
    
    public MyGvsEdge(MyGvsVertex<V> v, MyGvsVertex<V> w, E o) {
      super(v, w, o);
      label = o.toString();
    }
    
    @Override
    public GVSDefaultVertex[] getGVSVertizes() {
      GVSDefaultVertex[] vertices = new GVSDefaultVertex[2];
      vertices[0] = (GVSDefaultVertex)endVertices[0];
      vertices[1] = (GVSDefaultVertex)endVertices[1];
      return vertices;
    }

    @Override
    public int hasArrow() {
      return hasArrow;
    }
    
    public int setArrow(int hasArrow) {
      int oldValue = this.hasArrow;
      this.hasArrow = hasArrow;
      return oldValue;
    }

    @Override
    public String getGVSEdgeLabel() {
      return label;
    }
    
    public GVSEdgeTyp setGVSEdgeTyp(GVSEdgeTyp typ) {
      GVSEdgeTyp old = this.typ;
      this.typ = typ;
      return old;
    }

    @Override
    public GVSEdgeTyp getGVSEdgeTyp() {
      return typ;
    }

  }

  public AdjacencyListGraphGVS(GvsSupport gvsSupport) {
    super();
    this.gvsSupport = gvsSupport;
    this.gvsSupport.graph = this;
    gvsGraph = new GVSGraph("Dijkstra",  null);
  }
  
  /** Insert and return a new vertex with a given element.
   * @param o The element of this vertex.
   * @param gvsXPos The relative X-position for GVS (0..100).
   * @param gvsYPos The relative Y-position for GVS (0..100).
   * @return The new instantiated vertex.
   */
  public Vertex<V> insertVertex(V o, double gvsXPos, double gvsYPos) {
    MyGvsVertex<V> vv =  new MyGvsVertex<V>(o, gvsXPos, gvsYPos);
    VList.addLast(vv);
    Position<Vertex<V>> p = VList.last();
    vv.setLocation(p);
    gvsGraph.add(vv);
    if (gvsAllwaysDisplaying) {
      gvsGraph.display();
    }
    return vv;
  }
  
  /* (non-Javadoc)
   * @see net.datastructures.AdjacencyListGraph#insertEdge(net.datastructures.Vertex, net.datastructures.Vertex, java.lang.Object)
   */
  @Override
  public Edge<E> insertEdge(Vertex<V> v, Vertex<V> w, E o)
      throws InvalidPositionException {
    MyVertex<V> vv = checkVertex(v);
    MyVertex<V> ww = checkVertex(w);
    MyEdge<E> ee = null;
    MyGvsVertex<V> vvGvs = (MyGvsVertex<V>) vv;
    MyGvsVertex<V> wwGvs = (MyGvsVertex<V>) ww;
    ee = new MyGvsEdge<E>(wwGvs, vvGvs, o);
    Position<Edge<E>> pv = vv.insertIncidence(ee);
    Position<Edge<E>> pw = ww.insertIncidence(ee);
    ee.setIncidences(pv, pw);
    EList.addLast(ee);
    Position<Edge<E>> pe = EList.last();
    ee.setLocation(pe);
    if (gvsGraph != null) {
      gvsGraph.add((MyGvsEdge<E>) ee);
      if (gvsAllwaysDisplaying) {
        gvsGraph.display();
      }
    }
    ee.put(WEIGHT, o);
    return ee;
  }

  /**
   * @param displaying If the GVS-View shall be updated after any change.
   * @return The old value.
   */
  public boolean setGvsDisplaying(boolean displaying) {
    boolean oldValue =gvsAllwaysDisplaying;
    gvsAllwaysDisplaying = displaying;
    return oldValue;
  }

  /**
   * Displays the graph on the GVS-Server.
   */
  public void display() {
    gvsGraph.display();
  }
  
  /**
   * Disconnects from the GVS-Server.
   */
  public void disconnectServer() {
    gvsGraph.disconnect();
  }


}
