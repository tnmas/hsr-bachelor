package ch.hsr.prog2.dijkstragvs;

import java.util.Iterator;
import java.util.logging.Logger;

import net.datastructures.NodePositionList;

@SuppressWarnings({"unchecked"})

public class NodePositionListGVS<E> extends NodePositionList<E> {
 
  GvsSupport gvsSupport;
  
  private static final Logger log = Logger.getLogger(LinkedHashMapGVS.class.getName());

  public NodePositionListGVS(GvsSupport gvsSupport) {
    log.fine("");
    this.gvsSupport = gvsSupport;
  }

  @Override
  public Iterator<E> iterator() {
    log.fine("");
    return new ElementIteratorGVS<E>(this, gvsSupport); 
  }

}
