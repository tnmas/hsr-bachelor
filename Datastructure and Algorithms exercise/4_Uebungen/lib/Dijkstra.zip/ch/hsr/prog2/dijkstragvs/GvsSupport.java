package ch.hsr.prog2.dijkstragvs;

import gvs.typ.GVSDefaultTyp.LineColor;
import gvs.typ.GVSDefaultTyp.LineStyle;
import gvs.typ.GVSDefaultTyp.LineThickness;
import gvs.typ.edge.GVSEdgeTyp;
import gvs.typ.vertex.GVSEllipseVertexTyp;
import gvs.typ.vertex.GVSVertexTyp;
import gvs.typ.vertex.GVSEllipseVertexTyp.FillColor;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import net.datastructures.AdaptablePriorityQueue;
import net.datastructures.AdjacencyListGraph;
import net.datastructures.Edge;
import net.datastructures.Graph;
import net.datastructures.Vertex;
import ch.hsr.prog2.dijkstragvs.AdjacencyListGraphGVS.MyGvsEdge;
import ch.hsr.prog2.dijkstragvs.AdjacencyListGraphGVS.MyGvsVertex;

 @SuppressWarnings({"unchecked", "hiding"})

public class GvsSupport<V,E> {
  
  AdjacencyListGraphGVS<V,E> graph;
  
  public static int DELAY; // Delay-Time in ms
  
  private Vertex<V> actualVertex;
  private Edge<E> actualEdge;
  private static GVSEdgeTyp lastEdgeTyp;
  private static int lastArrows;
  
  
  private static final Logger log = Logger.getLogger(GvsSupport.class.getName());
  
  public GvsSupport() {
  }
  
  public void set(AdaptablePriorityQueue<Integer, Vertex<V>> apq,
      Map<Vertex<V>, Integer> distances,
      Map<Vertex<V>, Edge<E>> parents) {
    ((HeapAdaptablePriorityQueueGVS)apq).gvsSupport = this;
    ((LinkedHashMapGVS)distances).gvsSupport = this;
    ((LinkedHashMapGVS)parents).gvsSupport = this;
    this.parents = parents;
  }
  
  Set<AdjacencyListGraph<V,E>.MyVertex<V>> cloud = 
    new LinkedHashSet<AdjacencyListGraph<V,E>.MyVertex<V>>();
  
  public Map<Vertex<V>, Integer> distances;
  public Map<Vertex<V>, Edge<E>> parents;
  

  public static <V,E> void setBack(Graph<V, E> graph, Edge<E> e) {
    if (e instanceof MyGvsEdge) {
      MyGvsEdge gvsEdge = (MyGvsEdge)e;
      GVSEdgeTyp backTyp = new GVSEdgeTyp(
        LineColor.green, LineStyle.dashed, LineThickness.standard);
      gvsEdge.setGVSEdgeTyp(backTyp);
      display(graph);
    }
  }
  
  public static <V,E> void setFound(Graph<V, E> graph, Vertex<V> v) {
    if (v instanceof MyGvsVertex) {
      GVSVertexTyp foundType = new GVSEllipseVertexTyp(
        LineColor.gray, LineStyle.standard, LineThickness.bold, FillColor.red);
      MyGvsVertex gvsVertex = (MyGvsVertex)v;
      gvsVertex.setGVSVertexTyp(foundType);
      display(graph);
    }
  }
  
  public static <V,E> void setTesting(Graph<V, E> graph, Vertex<V> v) {
    if (v instanceof MyGvsVertex) {
      GVSVertexTyp foundType = new GVSEllipseVertexTyp(
        LineColor.blue, LineStyle.dashed, LineThickness.bold, FillColor.red);
      MyGvsVertex gvsVertex = (MyGvsVertex)v;
      gvsVertex.setGVSVertexTyp(foundType);
      display(graph);
    }
  }
  
  public <V,E> void setChanged(Vertex<V> v) {
    if (v instanceof MyGvsVertex) {
      LineColor lineColor = null; 
      LineStyle lineStyle = null;
      LineThickness lineThickness = null;
      FillColor fillColor = null;
      MyGvsVertex gvsVertex = (MyGvsVertex)v;
      GVSEllipseVertexTyp old = (GVSEllipseVertexTyp)gvsVertex.getGVSVertexTyp();
      if (old != null) {
        lineColor = old.getLineColor();
        lineStyle = old.getLineStyle();
        lineThickness = old.getLineThickness();
        fillColor = old.getFillColor();
      } else {
        lineColor = LineColor.standard;
        lineStyle = LineStyle.standard;
        lineThickness = LineThickness.standard;
        fillColor = FillColor.standard;
      }
      GVSVertexTyp changedType = new GVSEllipseVertexTyp(
        LineColor.red, LineStyle.dashed, lineThickness, fillColor);
      gvsVertex.setGVSVertexTyp(changedType);
      display(graph);
      sleep(DELAY);
      changedType = new GVSEllipseVertexTyp(
        lineColor, lineStyle, lineThickness, fillColor);
      gvsVertex.setGVSVertexTyp(changedType);
    }
  }
  
  public static <V,E> void setTesting(Graph<V, E> graph, Edge<E> e) {
    if (e instanceof MyGvsEdge) {
      MyGvsEdge gvsEdge = (MyGvsEdge)e;
      GVSEdgeTyp discoverdTyp = new GVSEdgeTyp(
        LineColor.blue, LineStyle.dashed, LineThickness.standard);
      gvsEdge.setGVSEdgeTyp(discoverdTyp);
      //gvsEdge.setArrow(1);
      display(graph);
    }
  }
  
  public void setTesting(Graph<V, E> graph, Vertex<V> v, Edge<E> e) {
    if (e instanceof MyGvsEdge) {
      log.info(e.toString());
      MyGvsEdge gvsEdge = (MyGvsEdge)e;
      GVSEdgeTyp testingTyp = new GVSEdgeTyp(
        LineColor.blue, LineStyle.dashed, LineThickness.standard);
      gvsEdge.setGVSEdgeTyp(testingTyp);
      if (gvsEdge.endVertices()[0] == v) {
        gvsEdge.setArrow(2);
      }
      else { 
        gvsEdge.setArrow(1);
      }
      display(graph);
      sleep(DELAY);
    }
  }
  
  public void setTestingStart(Graph<V, E> graph, Vertex<V> v, Edge<E> e) {
    MyGvsEdge gvsEdge = (MyGvsEdge)e;
    lastEdgeTyp = gvsEdge.getGVSEdgeTyp();
    lastArrows = gvsEdge.hasArrow();
    setTesting(graph, v, e);
  }
  
  public void setTestingStart(Edge<E> e) {
    log.fine(e.toString());
    MyGvsEdge gvsEdge = (MyGvsEdge)e;
    lastEdgeTyp = gvsEdge.getGVSEdgeTyp();
    lastArrows = gvsEdge.hasArrow();
    actualEdge = e;
    setTesting(graph, actualVertex, e);
  }
  
  public void setTestingEnd() {
    setTestingEnd(graph, actualVertex, actualEdge);
  }

  
  public static <V,E> void setTestingEnd(Graph<V, E> graph, Vertex<V> v, Edge<E> e) {
    log.fine(v+" / "+e);
    if (e == null) {
      return;
    }
    MyGvsEdge gvsEdge = (MyGvsEdge)e;
    gvsEdge.setGVSEdgeTyp(lastEdgeTyp);
    lastEdgeTyp = null;
    gvsEdge.setArrow(lastArrows);
    lastArrows = -1;
    display(graph);
  }
  
  public static <V,E> void newParentEdge(Graph<V, E> graph, Edge<E> e) {
    log.info(e == null ? "null" : e.toString());
    if (e instanceof MyGvsEdge) {
      MyGvsEdge gvsEdge = (MyGvsEdge)e;
      GVSEdgeTyp discoveredTyp = new GVSEdgeTyp(
        LineColor.red, LineStyle.through, LineThickness.standard);
      gvsEdge.setGVSEdgeTyp(discoveredTyp);
      gvsEdge.setArrow(0);
      lastEdgeTyp = discoveredTyp;
    }
  }
  
  public static <V,E> void setDiscovered(Graph<V, E> graph, Vertex<V> v) {
    log.fine(v.toString());
    if (v instanceof MyGvsVertex) {
      MyGvsVertex gvsVertex = (MyGvsVertex)v;
      GVSVertexTyp discoverdTyp = new GVSEllipseVertexTyp(
        LineColor.red, LineStyle.through, LineThickness.standard, FillColor.ligthBlue);
      gvsVertex.setGVSVertexTyp(discoverdTyp);
      //gvsEdge.setArrow(1);
      display(graph);
    }
    sleep(DELAY);
  }

  public <V,E> void updateVertex(Vertex<V> v,  Map<Vertex<V>, E> distances) {
    AdjacencyListGraph<V,E>.MyVertex<V> myVertex = (AdjacencyListGraph<V,E>.MyVertex<V>)v;
    String element = myVertex.element().toString();
    Integer i = (Integer)distances.get(v);
    if(i.equals(Integer.MAX_VALUE)) {
      element = element + ":# ";
    }
    else {
      String distance = String.format("%-2s", String.valueOf(i));
      int pos = element.indexOf(':');
      if (pos == -1) {
        element = element + ":"+distance;
      }
      else {
        element = element.substring(0, pos) + ":"+distance;
      }
    }
    myVertex.setElement((V)element);
    setChanged((Vertex<V>)myVertex);
  }
  
  public void newParentEdge(Edge<E> oldParentEdge, Edge<E> newParentEdge) {
    if (oldParentEdge != null) {
      MyGvsEdge gvsEdge = (MyGvsEdge)oldParentEdge;
      GVSEdgeTyp backTyp = new GVSEdgeTyp(
        LineColor.standard, LineStyle.standard, LineThickness.standard);
      gvsEdge.setGVSEdgeTyp(backTyp);
    }
    newParentEdge(graph, newParentEdge);
  }
  
  public void newVertexInCloud(Vertex<V> vertex) {
    log.info(vertex.toString());
    setDiscovered((AdjacencyListGraphGVS)graph, vertex);
    actualVertex = vertex;
  }

  public static void display(Graph graph) {
    ((AdjacencyListGraphGVS)graph).display();
  }
  
  public static void sleep(int delay) {
    try {
      Thread.sleep(delay);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  public void setGraph(AdjacencyListGraph<String, String> graph) {
    this.graph = (AdjacencyListGraphGVS)graph;
  }


}
